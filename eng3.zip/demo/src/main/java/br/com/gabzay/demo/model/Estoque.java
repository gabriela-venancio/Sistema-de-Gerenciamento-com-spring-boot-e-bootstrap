package br.com.gabzay.demo.model;

public class Estoque {

}
